function get_browser_name() {
	return navigator.appName;
}