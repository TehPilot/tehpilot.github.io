"Unwelcome Passenger"
by TehPilot

Music by TheFugue
Sound effects custom or from freesound.org
(all CC0 licensed)

Extract the zip folder and double click the executable.
Gameplay only uses left mouse button ("click").

Made for GMC Jam #4, "Voyage"
Last modified 29 May 2017

Thanks for playing!
http://tehpilot.com/ for more works.