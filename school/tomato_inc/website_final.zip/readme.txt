Project brought together with the amazing help of Group N.

<3

http://tehpilot.github.io/school/tomato_inc/index.html
https://dl.dropboxusercontent.com/u/36650520/~cs146/finalWebsite/index.html

Live mirrors for the website. Some features (PhoneViewer) might not work as intended due to security concerns.

The PhoneViewer was constructed with the HTML5 export in GameMaker: Studio (v1.3). Functionality that allowed the program to access data on the form was custom written as an extension (JS library). Code for the PhoneViewer is obfuscated as a product of the export module; if you're interested in the inner workings I'll be more than happy to detail what I did in GM:S.