function getRed() {
	return bodyRed;
	}
	
function getGreen() {
	return bodyGreen;
	}
	
function getBlue() {
	return bodyBlue;
	}