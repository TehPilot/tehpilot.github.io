﻿using UnityEngine;
using System.Collections;

public class BreakoutKillzone : MonoBehaviour 
{
	public BreakoutBallFactory ballFactory;
	
	void OnTriggerEnter2D ( Collider2D other )
	{
		Debug.Log ( "Entering the Killzone!" );
		
		if ( other.gameObject.tag == "ballObject" )
		{
			Destroy( other.gameObject );
			
			ballFactory.doWeHaveABallAlready = false;
		}
	}
}
