﻿using UnityEngine;
using System.Collections;

public class BreakoutScoreKeeper : MonoBehaviour 
{
	public int blocksRemaining;
	public BreakoutBlockFactory ourFactory;


	// Subtract from that number
	// Victory when the number is zero

	void Start ()
	{
		// Set the number of blocks
		blocksRemaining = ourFactory.numberOfRows * ourFactory.numberOfColumns;
	}

	void Update ()
	{
		if ( blocksRemaining <= 0 )
			Application.LoadLevel( "Victory" );
	}

}
