﻿using UnityEngine;
using System.Collections;

public class BreakoutBlockFactory : MonoBehaviour 
{
	public int numberOfRows;
	public int numberOfColumns;
	public GameObject blockPrefab;


	void Start ()
	{
		for ( int i = 0; i <= (numberOfColumns - 1) / 2; i++ )
		{
			for ( int j = numberOfRows; j > 0; j-- )
			{
				if (i == 0)
				{
					//center column
					Instantiate ( blockPrefab, new Vector3( i, j, 0 ), Quaternion.identity );
				}
				else
				{
					//side columns (one to the left, one to the right)
					Instantiate ( blockPrefab, new Vector3( i * 2, j, 0 ), Quaternion.identity );
					Instantiate ( blockPrefab, new Vector3( -(i * 2), j, 0 ), Quaternion.identity );
				}

			}
		}
	}
}
