﻿using UnityEngine;
using System.Collections;

public class BreakoutBallFactory : MonoBehaviour 
{
	public GameObject ballPrefab;
	public bool doWeHaveABallAlready;
	
	void Start ()
	{
		Respawn ();
	}

	void Update ()
	{
		// This is for clicking the mouse and spawning a ball
		if ( Input.GetMouseButtonDown(0) && !doWeHaveABallAlready )
		{
			Respawn ();
		}
	}
	
	public void Respawn ()
	{
		GameObject ourBall;
		float randomX = Random.Range (-100, 100);

		// Instantiate a ball!
		ourBall = (GameObject) Instantiate ( ballPrefab, transform.position, Quaternion.identity );
		ourBall.GetComponent<Rigidbody2D>().AddForce( new Vector2 ( randomX, 50f ) );

		doWeHaveABallAlready = true;
	}
}
