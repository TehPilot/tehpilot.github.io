﻿using UnityEngine;
using System.Collections;

public class PaddleController : MonoBehaviour 
{
	public string upKey;
	public string downKey;
	public float speed;

	void Update () 
	{
		// This is for player input
		if ( Input.GetKey( upKey ) && ( transform.position.y < 3.3f ) )
		{
			transform.Translate( new Vector2( 0, speed * Time.deltaTime ), Space.World );
		}

		if ( Input.GetKey( downKey ) && ( transform.position.y > -3.3f ) )
		{
			transform.Translate( new Vector2( 0, -speed * Time.deltaTime ), Space.World );
		}
	}

	// Space.World
	// Time.deltatime
}
