﻿using UnityEngine;
using System.Collections;

public class BreakoutPaddle : MonoBehaviour 
{
	public Vector2 screenToWorld;

	void Update () 
	{
		// Move the Paddle with the mouse
		float tempX = Input.mousePosition.x;

		screenToWorld = new Vector2( ((tempX / Screen.width) * 20) - 10, -4 );
		transform.position = screenToWorld;

		// Constrain the Paddle
		if ( transform.position.x < -10 )
			transform.position = new Vector2( -10, -4 );

		if ( transform.position.x > 10 )
			transform.position = new Vector2( 10, -4 );
	}

	void OnCollisionEnter2D ( Collision2D other )
	{
		float paddleX, paddleY, ballX, ballY;

		if (other.gameObject.tag == "ballObject")
		{

			//capture coordinates of ball and paddle
			paddleX = transform.position.x;
			paddleY = transform.position.y;
			ballX = other.gameObject.transform.position.x;
			ballY = other.gameObject.transform.position.y;

			//reset the ball's velocity
			//other.gameObject.GetComponent<Rigidbody2D>().velocity = Vector3.zero;

			//set the ball's velocity based on its position relative to the paddle (allowing for the player to control the ball's direction)
			other.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2((ballX - paddleX) * 7.5f, (ballY - paddleY) * 7.5f);
		}
	}

}
