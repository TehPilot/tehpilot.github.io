﻿using UnityEngine;
using System.Collections;

public class BreakoutBlock : MonoBehaviour 
{
	void OnCollisionEnter2D ( Collision2D other )
	{
		Destroy (this.gameObject);
	}
}
