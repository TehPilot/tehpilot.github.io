﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameMaster : MonoBehaviour 
{
	public GameObject ballPrefab;
	public Transform ballOriginTransform;
	public Text scoreLeftText;
	public Text scoreRightText;
	public int scoreLeft;
	public int scoreRight;

	void Start () 
	{
		Respawn( );
		scoreLeft = 0;
		scoreRight = 0;
		scoreLeftText.text = "" + scoreLeft;
		scoreRightText.text = "" + scoreRight;
	}

	public void AddPoint ( string side )
	{
		if ( side == "right" )
		{
			scoreRight++;
			scoreRightText.text = "" + scoreRight;
		}
		else
		{
			scoreLeft++;
			scoreLeftText.text = "" + scoreLeft;
		}
	}

	public void Respawn ()
	{
		// A variable for the ball so we don't lose it...
		GameObject theBall;
		
		// Spawn the ball at the origin
		theBall = (GameObject) Instantiate( ballPrefab, ballOriginTransform.position, Quaternion.identity );
		
		// Spike the ball in a random direction (in X and Y of course!)
		theBall.GetComponent<Rigidbody2D>().AddForce( new Vector2( 100f, 100f ) );
	}
}
