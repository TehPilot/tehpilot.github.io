﻿using UnityEngine;
using System.Collections;

public class Killzone : MonoBehaviour 
{
	public GameMaster ballController;

	void OnTriggerEnter2D ( Collider2D other )
	{
		Debug.Log ( "Entering the Killzone!" );

		if ( other.gameObject.tag == "killable" )
		{
			Destroy( other.gameObject );

			if ( gameObject.name == "Killzone (Right)" )
				ballController.AddPoint( "right" );
			else
				ballController.AddPoint( "left" );

			ballController.Respawn();
		}
	}
}
